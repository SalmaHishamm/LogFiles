import cx_Oracle
import pandas as pd
import re
import json
import logging


#Config log setting
logging.basicConfig(
    filename='log_file.log', 
    level=logging.DEBUG,  # Specify the log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s [%(levelname)s]: %(message)s', 
    datefmt='%Y-%m-%d %H:%M:%S'   
)



#Read from json file
def readConfig () :
 with open("config.json") as f:
  config = json.load(f)
  str=config["Database"]
  return str



#Clean input from any alphabets(return numbers)
def clean (number): 
  pattern = re.compile("[^\d]")
  new_number = pattern.sub("", str(number))
  return new_number

 
    

try:
    
    file_path='Table.xlsx'
    sheet_name='Sheet1'
    df = pd.read_excel(file_path,sheet_name)
    
     
    ConnStr=readConfig()
    connection = cx_Oracle.connect(ConnStr)
    cursor=connection.cursor()
    
    col1=df['CouponValue']
    col2=df['Code']
    col3=df['DiscountID']
    col4=df['TransactionID']
    
    col1_list=col1.tolist()
    col2_list=col2.tolist()
    col3_list=col3.tolist()
    col4_list=col4.tolist()
    
    # print(col1)
    # print(col1_list)
    
    
    i=0
    n=len(col1_list)
    #print(n)
    
    if (col1_list[0]=='nan'):
        raise pd.errors.EmptyDataError
    
    #insert_statement = "INSERT INTO coupons (COUPONVALUE,CODE,DISCOUNTID,DISCOUNTTYPE,DEALTYPE,TRANSACTIONID,ECODE,EDESC) VALUES (:val1, :val2 , :val3 ,'R','RED',:val6 ,2,'j')"
   
    schema_name = 'SYSADM'
    procedure_name = 'GET_COUPON_CODE_REDMPTION'
    input4='R'
    input5='RED'
    # input7='ECODE'
    # input8='EDESC'
    
    
    output7=None
    output8=None

    out_ecode = cursor.var(cx_Oracle.STRING)
    out_edesc = cursor.var(cx_Oracle.STRING)
    
    
    
    
    for i in range(0,n) :
     
     value1=clean(col1_list[i])
     value2=col2_list[i]
     value3=col3_list[i]
     value6=col4_list[i]
     
     
     #cursor.execute(insert_statement, {"val1": str(value1), "val2": str(value2) , "val3": str(value3) , "val6": str(value6)})
     cursor.callproc(f"{schema_name}.{procedure_name}", [value1,value2,value3,input4,input5,value6,output7, output8])
     connection.commit() 
     
    cursor.close()
    logging.info(f'Data Inserted Successfully')
     
     
    
     
except pd.errors.EmptyDataError:
    print("The Excel file is empty or has no data.")
    logging.error(f'Error occurred: The Excel file is empty or has no data.')
except FileNotFoundError:
    print("File 'Table.xlsx' not found or incorrect file path.")
    logging.error(f"Error occurred: File 'Table.xlsx' not found or incorrect file path.")
except cx_Oracle.DatabaseError as e:
    print ("An error occurred:", e)
    logging.error(f'Error occurred: {str(e)}')
except Exception as e:
    print("An error occurred:", e)
    logging.error(f'Error occurred:{str(e)}.')




